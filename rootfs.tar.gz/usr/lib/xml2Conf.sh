#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/usr/lib"
XML2_LIBS="-lxml2 -L/home/user/work/fpga/DE10/rootfs/output/host/usr/arm-buildroot-linux-gnueabihf/sysroot/usr/lib -lz   -L/home/user/work/fpga/DE10/rootfs/output/host/usr/arm-buildroot-linux-gnueabihf/sysroot/usr/lib -llzma      -lm "
XML2_INCLUDEDIR="-I/usr/include/libxml2"
MODULE_VERSION="xml2-2.9.4"

